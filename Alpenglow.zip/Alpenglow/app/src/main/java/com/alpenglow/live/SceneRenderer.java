package com.alpenglow.live;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import java.util.Calendar;
import java.util.Random;
import java.util.TimeZone;

/**
 * Procedural "Alpenglow" scene. Pure android.graphics, no allocation in the hot path
 * (all paths, shaders and arrays are built on resize / palette change only).
 *
 * Draw order (back to front):
 *   sky, stars, aurora, moon, sun, clouds, birds, 4 mountain layers, lake (mirrored world + glitter),
 *   mist, foreground trees + land, fireflies, charge FX, unlock FX, vignette.
 */
final class SceneRenderer {

    // ------------------------------------------------------------------ math helpers
    private static final float PI = (float) Math.PI;
    private static final float TAU = 2f * PI;
    private static final int BLACK = 0xFF000000;
    private static final int WHITE = 0xFFFFFFFF;

    private static float clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
    private static float clamp01(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static float sin(float x) { return (float) Math.sin(x); }
    private static float cos(float x) { return (float) Math.cos(x); }
    private static float abs(float x) { return x < 0f ? -x : x; }
    private static float sqrt(float x) { return (float) Math.sqrt(x); }
    private static float pow(float x, float y) { return (float) Math.pow(x, y); }
    private static float smooth(float e0, float e1, float x) {
        float t = clamp01((x - e0) / (e1 - e0));
        return t * t * (3f - 2f * t);
    }

    private static int mix(int a, int b, float t) {
        t = clamp01(t);
        int aa = a >>> 24, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = b >>> 24, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int ra = (int) (aa + (ba - aa) * t + 0.5f);
        int rr = (int) (ar + (br - ar) * t + 0.5f);
        int rg = (int) (ag + (bg - ag) * t + 0.5f);
        int rb = (int) (ab + (bb - ab) * t + 0.5f);
        return (ra << 24) | (rr << 16) | (rg << 8) | rb;
    }

    private static int scaleRgb(int c, float s) {
        int r = (int) clamp(((c >> 16) & 255) * s, 0f, 255f);
        int g = (int) clamp(((c >> 8) & 255) * s, 0f, 255f);
        int b = (int) clamp((c & 255) * s, 0f, 255f);
        return (c & 0xFF000000) | (r << 16) | (g << 8) | b;
    }

    /** Colour with alpha replaced by a01 (0..1). */
    private static int alphaOf(int c, float a01) {
        int a = (int) (clamp01(a01) * 255f + 0.5f);
        return (a << 24) | (c & 0xFFFFFF);
    }

    private static int keyColor(float[] keys, int[] cols, float v) {
        int n = keys.length;
        if (v <= keys[0]) return cols[0];
        if (v >= keys[n - 1]) return cols[n - 1];
        int i = 0;
        while (i < n - 2 && v > keys[i + 1]) i++;
        return mix(cols[i], cols[i + 1], (v - keys[i]) / (keys[i + 1] - keys[i]));
    }

    // ------------------------------------------------------------------ palettes
    // keyed by sun altitude (-1 deep night .. 1 noon). Rows: sky top, sky mid, horizon.
    private static final float[] KEY_ALT = {-1f, -0.34f, -0.12f, 0f, 0.10f, 0.30f, 1f};
    private static final int[][] DUSK = {
            {0xFF02030B, 0xFF070C24, 0xFF18295E},
            {0xFF050821, 0xFF11175A, 0xFF35449A},
            {0xFF161A62, 0xFF5A2A8A, 0xFFD2507E},
            {0xFF281F73, 0xFFB43A82, 0xFFFF8A4A},
            {0xFF3A52B4, 0xFFDE809E, 0xFFFFC27A},
            {0xFF3F86E2, 0xFF8FC4F4, 0xFFFFE6BC},
            {0xFF2A7DE0, 0xFF6CB5F4, 0xFFCDEBFF},
    };
    private static final int[][] DAWN = {
            {0xFF02030B, 0xFF070C24, 0xFF18295E},
            {0xFF050821, 0xFF11175A, 0xFF35449A},
            {0xFF1A2678, 0xFF6A5BAA, 0xFFF2A0AA},
            {0xFF30449A, 0xFFE58CA2, 0xFFFFCB8C},
            {0xFF4A7AD6, 0xFFA7C8F2, 0xFFFFE5B8},
            {0xFF3F86E2, 0xFF8FC4F4, 0xFFFFE6BC},
            {0xFF2A7DE0, 0xFF6CB5F4, 0xFFCDEBFF},
    };
    private static final float[] SUN_ALT = {-0.1f, 0f, 0.08f, 0.2f, 0.45f, 1f};
    private static final int[] SUN_COL = {0xFFFF4A24, 0xFFFF6A2E, 0xFFFF9A44, 0xFFFFC870, 0xFFFFE9B4, 0xFFFFF8E6};
    private static final float[] CHG_LVL = {0f, 0.2f, 0.5f, 0.97f, 1f};
    private static final int[] CHG_COL = {0xFFFF6B4A, 0xFFFFB347, 0xFF3DF2C4, 0xFF3DF2C4, 0xFFFFD36B};
    private static final int MOON_COL = 0xFFEEF2FF;
    private static final int MOON_GLOW = 0xFFA9BDFF;

    private static final double NEW_MOON_REF_MS = 947182440000.0;       // 2000-01-06 18:14 UTC
    private static final double SYNODIC_MS = 29.530588853 * 86400000.0;

    // ------------------------------------------------------------------ public inputs
    Settings cfg = new Settings();
    /** &lt;0 = follow the system clock; otherwise fixed hour 0..24 (used by the in-app preview). */
    float hourOverride = -1f;
    /** &lt;0 = real moon phase for today's date; otherwise 0..1 */
    float moonPhaseOverride = -1f;

    // ------------------------------------------------------------------ geometry
    private float W, H, dp, waterY, sunHorY, arcH;
    private boolean sized;
    private boolean dirty = true;

    // ------------------------------------------------------------------ time
    private float time;
    private long prevUp = -1L;
    private final Calendar cal = Calendar.getInstance();
    private long clkUp = -1L;
    private float clkHour;
    private float hour;
    private float builtHour = -99f;
    private float moonPhase;

    // ------------------------------------------------------------------ celestial state
    private float sunAlt, sunX, sunY, moonX, moonY, moonAlt, illum;
    private boolean moonUp, morning;
    private float nightness, dayness, amoledMix, starAlpha;

    // ------------------------------------------------------------------ dynamic inputs
    private float tiltX, tiltY, parX, parY;
    private float scrollTarget = 0.5f, scroll = 0.5f;
    private boolean plugged;
    private float level = 0.5f, chg;
    private float pulseT = -1f;
    private float unlockT = -1f, wakeT = -1f;
    private boolean lowPower;
    private float ampl = 1f;
    private float zoom;

    // ------------------------------------------------------------------ palette (rebuilt rarely)
    private int rawTop, rawMid, rawHor;
    private int skyTop, skyMid, skyHor;
    private int sunCol, hazeCol, shadowCol, foreCol, fogBase, chargeCol;
    private int cloudLit, cloudShade, birdCol;
    private float cloudAlpha, snowAlpha;
    private int snowCol;
    private Shader skyShader, waterShader, mistShader, sunHalo, moonHalo, bloomShader, rayShader;
    private Shader lineShader, chargeHalo, vignetteShader, streakSun, streakMoon;
    private final Shader[] auroraShader = new Shader[3];
    private Shader mwOuter, mwInner;

    // ------------------------------------------------------------------ paints / scratch
    private final Paint pFill = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
    private final Paint pGrad = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
    private final Paint pStroke = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
    private final Path tmpPath = new Path();
    private final Path moonPath = new Path();
    private final Matrix tmpM = new Matrix();
    private final Random rnd = new Random(1234L);

    // ------------------------------------------------------------------ lights
    private static final class Light {
        float x, y, strength, reach;
        Shader rim, glow;
    }
    private final Light sun = new Light();
    private final Light moon = new Light();

    // ------------------------------------------------------------------ mountain layers
    private static final int NL = 4;
    private static final class Layer {
        float depth, base, amp, round, tone, fog;
        int peaks, seed, treeCount;
        float topY, capDepth, treeH;
        final Path fill = new Path();
        final Path ridge = new Path();
        final Path snow = new Path();
        Shader fillShader;
    }
    private final Layer[] layers = new Layer[NL];

    // foreground
    private final Path landFill = new Path();
    private final Path landRidge = new Path();
    private static final int NTL = 7, NTR = 6;
    private final Path[] treesL = new Path[NTL];
    private final Path[] treesR = new Path[NTR];
    private float treeBase;

    // stars
    private static final int NSTAR = 230;
    private final float[] stX = new float[NSTAR], stY = new float[NSTAR], stR = new float[NSTAR];
    private final float[] stP = new float[NSTAR], stB = new float[NSTAR], stS = new float[NSTAR];

    // clouds
    private static final int NC = 6;
    private static final float[] C_CX = {0.10f, 0.42f, 0.75f, 0.28f, 0.62f, 0.92f};
    private static final float[] C_CY = {0.20f, 0.34f, 0.14f, 0.50f, 0.44f, 0.30f};
    private static final float[] C_SZ = {0.075f, 0.055f, 0.066f, 0.040f, 0.050f, 0.046f};
    private static final float[] C_SP = {0.0040f, 0.0060f, 0.0030f, 0.0080f, 0.0050f, 0.0070f};
    private static final float[] C_DP = {0.10f, 0.14f, 0.08f, 0.18f, 0.16f, 0.20f};
    private final float[] cOff = new float[NC];
    private static final float[] PUFF_DX = {-1.05f, -0.45f, 0.15f, 0.75f, 1.25f};
    private static final float[] PUFF_R = {0.42f, 0.62f, 0.78f, 0.58f, 0.38f};

    // streaks (thin twilight strata)
    private static final int NSTREAK = 4;
    private final float[] sX = new float[NSTREAK], sY = new float[NSTREAK], sLen = new float[NSTREAK], sSp = new float[NSTREAK];

    // birds
    private float flockX, flockY;
    private static final float[] B_DX = {0f, -0.035f, -0.07f, -0.02f, -0.055f};
    private static final float[] B_DY = {0f, 0.012f, 0.026f, -0.014f, -0.004f};
    private final Path birdPath = new Path();

    // fireflies
    private static final int NFF = 22;
    private final float[] ffX = new float[NFF], ffY = new float[NFF], ffP = new float[NFF], ffS = new float[NFF];

    // water ripples
    private static final int NRIP = 34;
    private final float[] rpX = new float[NRIP], rpY = new float[NRIP], rpL = new float[NRIP], rpP = new float[NRIP];
    private static final int NTAP = 4;
    private final float[] tapX = new float[NTAP], tapY = new float[NTAP], tapT = new float[NTAP];

    // shooting star
    private float ssT = -1f, ssCount = 9f, ssX, ssY, ssDx, ssDy;

    // charge motes
    private static final int NMOTE = 34;
    private final float[] mX = new float[NMOTE], mY = new float[NMOTE], mV = new float[NMOTE];
    private final float[] mL = new float[NMOTE], mS = new float[NMOTE], mP = new float[NMOTE];

    // ================================================================== construction
    SceneRenderer() {
        pStroke.setStyle(Paint.Style.STROKE);
        pStroke.setStrokeCap(Paint.Cap.ROUND);
        pStroke.setStrokeJoin(Paint.Join.ROUND);
        for (int i = 0; i < NL; i++) layers[i] = new Layer();
        for (int i = 0; i < NTL; i++) treesL[i] = new Path();
        for (int i = 0; i < NTR; i++) treesR[i] = new Path();
        Layer l;
        l = layers[0]; l.depth = 0.10f; l.base = 0.110f; l.amp = 0.170f; l.peaks = 5; l.round = 0.05f; l.tone = 0.26f; l.fog = 0.60f; l.seed = 11; l.capDepth = 0.20f;
        l = layers[1]; l.depth = 0.30f; l.base = 0.080f; l.amp = 0.120f; l.peaks = 6; l.round = 0.15f; l.tone = 0.46f; l.fog = 0.52f; l.seed = 23; l.capDepth = 0.14f;
        l = layers[2]; l.depth = 0.52f; l.base = 0.048f; l.amp = 0.085f; l.peaks = 7; l.round = 0.45f; l.tone = 0.67f; l.fog = 0.42f; l.seed = 37; l.treeCount = 9; l.treeH = 0.030f;
        l = layers[3]; l.depth = 0.72f; l.base = 0.022f; l.amp = 0.052f; l.peaks = 9; l.round = 0.80f; l.tone = 0.88f; l.fog = 0.34f; l.seed = 41; l.treeCount = 20; l.treeH = 0.026f;
    }

    void setSize(int w, int h) {
        if (w <= 0 || h <= 0) return;
        if (sized && (int) W == w && (int) H == h) return;
        W = w;
        H = h;
        dp = W / 360f;
        waterY = H * 0.64f;
        sunHorY = waterY - H * 0.20f;
        arcH = sunHorY - H * 0.13f;
        for (int i = 0; i < NL; i++) buildLayer(layers[i]);
        buildForeground();
        buildAmbient();
        vignetteShader = new RadialGradient(W * 0.5f, H * 0.5f, H * 0.78f,
                new int[]{0x00000000, 0x00000000, 0xA8000000}, new float[]{0f, 0.52f, 1f}, Shader.TileMode.CLAMP);
        sized = true;
        dirty = true;
    }

    // ================================================================== public setters
    void setTilt(float x, float y) { tiltX = clamp(x, -1f, 1f); tiltY = clamp(y, -1f, 1f); }
    void setScroll(float x01) { scrollTarget = clamp01(x01); }
    void setLowPower(boolean lp) { if (lp != lowPower) { lowPower = lp; dirty = true; } }
    void setPlugged(boolean p, float lvl) {
        lvl = clamp01(lvl);
        if (p && !plugged) pulseT = 0f;
        if (p != plugged || abs(lvl - level) > 0.02f) dirty = true;
        plugged = p;
        level = lvl;
    }
    void triggerChargePulse() { pulseT = 0f; }
    void triggerUnlock() { unlockT = 0f; }
    void triggerWake() { wakeT = 0f; }
    void invalidatePalette() { dirty = true; }
    boolean isAnimating() { return unlockT >= 0f || wakeT >= 0f || pulseT >= 0f; }

    void tap(float x, float y) {
        int slot = 0;
        float oldest = -1f;
        for (int i = 0; i < NTAP; i++) {
            if (tapT[i] < 0f || tapT[i] > 3f) { slot = i; oldest = 99f; break; }
            if (tapT[i] > oldest) { oldest = tapT[i]; slot = i; }
        }
        tapX[slot] = x;
        tapY[slot] = Math.max(y, waterY + H * 0.04f);
        tapT[slot] = 0f;
    }

    /** Three representative colours (primary, secondary, tertiary) for WallpaperColors. */
    int[] themeColors() {
        return new int[]{mix(rawMid, shadowCol, 0.1f) | 0xFF000000, rawHor | 0xFF000000, rawTop | 0xFF000000};
    }

    // ================================================================== frame entry
    void draw(Canvas c, long upMs, long wallMs) {
        if (!sized) return;
        float dt = (prevUp < 0L) ? 0.016f : (upMs - prevUp) / 1000f;
        prevUp = upMs;
        dt = clamp(dt, 0f, 0.1f);
        time += dt;
        if (time > 1800f) time -= 1800f;      // keep float precision after days of uptime

        updateClock(upMs, wallMs);
        computeCelestial();
        step(dt);
        if (dirty || abs(hour - builtHour) > 0.004f) rebuildPalette();
        aimLights();
        render(c);
    }

    // ================================================================== clock & sky state
    private void updateClock(long upMs, long wallMs) {
        double ph = (wallMs - NEW_MOON_REF_MS) / SYNODIC_MS;
        ph -= Math.floor(ph);
        moonPhase = moonPhaseOverride >= 0f ? clamp01(moonPhaseOverride) : (float) ph;
        illum = 0.5f * (1f - cos(TAU * moonPhase));

        if (hourOverride >= 0f) {
            hour = clamp(hourOverride, 0f, 23.999f);
            return;
        }
        if (clkUp < 0L || upMs - clkUp > 1000L || upMs < clkUp) {
            cal.setTimeZone(TimeZone.getDefault());   // follows travel / manual time-zone changes
            cal.setTimeInMillis(wallMs);
            clkHour = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60f
                    + cal.get(Calendar.SECOND) / 3600f + cal.get(Calendar.MILLISECOND) / 3600000f;
            clkUp = upMs;
        }
        float h = clkHour + (upMs - clkUp) / 3600000f;
        if (h >= 24f) h -= 24f;
        hour = h;
    }

    private void computeCelestial() {
        float sr = cfg.sunriseMin / 60f, ss = cfg.sunsetMin / 60f;
        if (ss - sr < 6f) ss = sr + 6f;
        float dayLen = ss - sr, nightLen = 24f - dayLen;
        float h = hour;
        float thS, thM = -1f;
        morning = h < (sr + ss) * 0.5f;
        if (h >= sr && h < ss) {
            thS = PI * (h - sr) / dayLen;
        } else {
            float nf = h >= ss ? (h - ss) / nightLen : (h + 24f - ss) / nightLen;
            nf = clamp01(nf);
            thS = PI + PI * nf;
            thM = PI * nf;
        }
        sunAlt = sin(thS);
        sunX = W * (0.5f - 0.37f * cos(thS));
        sunY = sunHorY - sin(thS) * arcH;
        moonUp = thM >= 0f;
        if (moonUp) {
            moonAlt = sin(thM);
            moonX = W * (0.5f - 0.37f * cos(thM));
            moonY = sunHorY - sin(thM) * arcH;
        } else {
            moonAlt = -1f;
        }
        nightness = smooth(0.10f, -0.30f, sunAlt);
        dayness = smooth(-0.05f, 0.35f, sunAlt);
        starAlpha = smooth(-0.04f, -0.36f, sunAlt);
    }

    // ================================================================== simulation step
    private void step(float dt) {
        ampl = cfg.parallax ? cfg.parallaxPct / 100f : 0f;

        float auto = 0.16f * sin(time * 0.21f);
        float tx = cfg.parallax ? tiltX + auto : auto;
        float ty = cfg.parallax ? tiltY + 0.5f * auto : 0f;
        float k = 1f - (float) Math.exp(-dt * 6.5f);
        parX += (tx - parX) * k;
        parY += (ty - parY) * k;
        scroll += (scrollTarget - scroll) * (1f - (float) Math.exp(-dt * 8f));

        // charge envelope
        float chgT = (cfg.charging && plugged) ? 1f : 0f;
        float rate = chgT > chg ? 1.1f : 0.7f;
        chg += (chgT - chg) * (1f - (float) Math.exp(-dt * rate * 2f));
        if (chg < 0.002f && chgT == 0f) chg = 0f;
        if (pulseT >= 0f) { pulseT += dt; if (pulseT > 2.6f) pulseT = -1f; }

        // unlock / wake
        if (unlockT >= 0f) { unlockT += dt; if (unlockT > 1.9f) unlockT = -1f; }
        if (wakeT >= 0f) { wakeT += dt; if (wakeT > 1.0f) wakeT = -1f; }
        float up = 0f;
        if (unlockT >= 0f && cfg.unlock) {
            float u = clamp01(unlockT / 1.9f);
            up = sin(PI * pow(u, 0.55f));
        }
        float wp = 0f;
        if (wakeT >= 0f) {
            float u = clamp01(wakeT / 1.0f);
            wp = (1f - u) * (1f - u) * (1f - u);
        }
        unlockP = up;
        wakeP = wp;
        zoom = up * 0.075f + wp * 0.035f;

        // clouds
        for (int i = 0; i < NC; i++) {
            cOff[i] += C_SP[i] * W * dt;
            if (cOff[i] > 1.5f * W) cOff[i] -= 1.5f * W;
        }

        // birds
        flockX += W * 0.034f * dt;
        if (flockX > W * 1.25f) {
            flockX = -0.3f * W;
            flockY = waterY * (0.16f + 0.30f * rnd.nextFloat());
        }

        // taps
        for (int i = 0; i < NTAP; i++) if (tapT[i] >= 0f) { tapT[i] += dt; if (tapT[i] > 3f) tapT[i] = -1f; }

        // shooting star
        if (cfg.life && starAlpha > 0.6f) {
            if (ssT < 0f) {
                ssCount -= dt;
                if (ssCount <= 0f) {
                    ssT = 0f;
                    ssX = W * (0.35f + 0.65f * rnd.nextFloat());
                    ssY = waterY * (0.05f + 0.25f * rnd.nextFloat());
                    float a = (float) Math.toRadians(150f + 20f * rnd.nextFloat());
                    ssDx = cos(a);
                    ssDy = sin(a);
                    ssCount = 14f + 26f * rnd.nextFloat();
                }
            }
        }
        if (ssT >= 0f) { ssT += dt; if (ssT > 0.9f) ssT = -1f; }

        // charge motes
        if (chg > 0.03f) {
            for (int i = 0; i < NMOTE; i++) {
                if (mL[i] <= 0f) {
                    if (rnd.nextFloat() < dt * 1.5f) {
                        mX[i] = W * (0.05f + 0.9f * rnd.nextFloat());
                        mY[i] = waterY + H * (0.02f + 0.22f * rnd.nextFloat());
                        mV[i] = H * (0.05f + 0.09f * rnd.nextFloat());
                        mS[i] = 1.1f + 1.7f * rnd.nextFloat();
                        mP[i] = rnd.nextFloat() * TAU;
                        mL[i] = 1f;
                    }
                } else {
                    mY[i] -= mV[i] * dt;
                    mX[i] += sin(time * 1.3f + mP[i]) * W * 0.012f * dt * 6f;
                    mL[i] -= dt * (0.16f + 0.1f * mS[i] * 0.2f);
                }
            }
        }
    }

    private float unlockP, wakeP;

    // ================================================================== palette rebuild
    private void rebuildPalette() {
        builtHour = hour;
        dirty = false;

        // sky
        int[][] set = morning ? DAWN : DUSK;
        int i = 0;
        while (i < KEY_ALT.length - 2 && sunAlt > KEY_ALT[i + 1]) i++;
        float t = clamp01((sunAlt - KEY_ALT[i]) / (KEY_ALT[i + 1] - KEY_ALT[i]));
        t = t * t * (3f - 2f * t);
        rawTop = mix(set[i][0], set[i + 1][0], t);
        rawMid = mix(set[i][1], set[i + 1][1], t);
        rawHor = mix(set[i][2], set[i + 1][2], t);

        // amoled mix
        float a;
        if (cfg.amoled == 2) a = 1f;
        else if (cfg.amoled == 1) a = nightness;
        else a = 0f;
        if (lowPower) a = Math.max(a, 0.85f);
        amoledMix = a;
        skyTop = mix(rawTop, BLACK, 0.985f * a);
        skyMid = mix(rawMid, BLACK, 0.95f * a);
        skyHor = mix(rawHor, BLACK, 0.62f * a);

        sunCol = keyColor(SUN_ALT, SUN_COL, sunAlt);
        chargeCol = keyColor(CHG_LVL, CHG_COL, level);

        hazeCol = mix(rawHor, rawMid, 0.5f);
        shadowCol = mix(scaleRgb(rawTop, 0.30f), 0xFF0A2B3A, 0.40f * dayness);
        foreCol = mix(scaleRgb(shadowCol, 0.45f), BLACK, 0.96f * a);
        fogBase = mix(mix(rawHor, rawMid, 0.15f), BLACK, 0.90f * a);

        // lights
        sun.reach = W * 1.0f;
        moon.reach = W * 0.9f;
        sun.rim = new RadialGradient(0f, 0f, 1f, new int[]{alphaOf(sunCol, 1f), alphaOf(sunCol, 0.45f), alphaOf(sunCol, 0f)},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP);
        sun.glow = new RadialGradient(0f, 0f, 1f, new int[]{alphaOf(sunCol, 0.62f), alphaOf(sunCol, 0.20f), alphaOf(sunCol, 0f)},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP);
        moon.rim = new RadialGradient(0f, 0f, 1f, new int[]{alphaOf(MOON_GLOW, 1f), alphaOf(MOON_GLOW, 0.4f), alphaOf(MOON_GLOW, 0f)},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP);
        moon.glow = new RadialGradient(0f, 0f, 1f, new int[]{alphaOf(MOON_GLOW, 0.5f), alphaOf(MOON_GLOW, 0.16f), alphaOf(MOON_GLOW, 0f)},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP);
        sun.strength = smooth(-0.12f, 0.08f, sunAlt) * (1f - 0.5f * clamp01(sunAlt));
        moon.strength = moonUp ? (0.30f + 0.70f * illum) * smooth(0.25f, -0.15f, sunAlt) * smooth(0f, 0.1f, moonAlt + 0.05f) : 0f;

        // sky & friends
        skyShader = new LinearGradient(0f, 0f, 0f, waterY, new int[]{skyTop, skyMid, skyHor}, new float[]{0f, 0.58f, 1f}, Shader.TileMode.CLAMP);
        sunHalo = unitRadial(sunCol, 0.9f, 0.30f);
        moonHalo = unitRadial(MOON_GLOW, 0.8f, 0.28f);
        bloomShader = unitRadial(mix(sunCol, rawHor, 0.35f), 0.85f, 0.35f);
        rayShader = new RadialGradient(0f, 0f, H * 1.25f, new int[]{alphaOf(sunCol, 0.85f), alphaOf(sunCol, 0.35f), alphaOf(sunCol, 0f)},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP);
        int sc = mix(sunCol, WHITE, 0.6f);
        streakSun = new LinearGradient(0f, 0f, 1f, 0f, new int[]{alphaOf(sc, 0f), alphaOf(sc, 1f), alphaOf(sc, 0f)}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
        streakMoon = new LinearGradient(0f, 0f, 1f, 0f, new int[]{alphaOf(MOON_COL, 0f), alphaOf(MOON_COL, 1f), alphaOf(MOON_COL, 0f)}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);

        // water
        int wTop = mix(skyHor, skyMid, 0.2f);
        int wMid = mix(skyMid, shadowCol, 0.5f);
        int wBot = scaleRgb(mix(skyTop, shadowCol, 0.6f), 0.55f);
        waterShader = new LinearGradient(0f, waterY, 0f, H, new int[]{alphaOf(wTop, 0.30f), alphaOf(wMid, 0.62f), alphaOf(wBot, 0.93f)},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP);
        float mistH = H * 0.075f;
        mistShader = new LinearGradient(0f, waterY - mistH, 0f, waterY + mistH, new int[]{alphaOf(fogBase, 0f), alphaOf(fogBase, 0.62f), alphaOf(fogBase, 0f)},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);

        // mountain layers
        int lightCol = sun.strength >= moon.strength ? sunCol : MOON_COL;
        float lightAmt = Math.max(sun.strength, moon.strength * 0.7f);
        for (int li = 0; li < NL; li++) {
            Layer L = layers[li];
            int col = mix(hazeCol, shadowCol, L.tone);
            col = mix(col, BLACK, 0.94f * a);
            int fog = mix(col, fogBase, L.fog);
            int cap = mix(col, mix(lightCol, WHITE, 0.2f), 0.16f * lightAmt * (1f - L.tone * 0.5f) * (1f - a * 0.8f));
            L.fillShader = new LinearGradient(0f, L.topY, 0f, waterY, new int[]{cap, col, fog}, new float[]{0f, 0.30f, 1f}, Shader.TileMode.CLAMP);
        }

        // clouds
        float tw = 1f - smooth(0f, 0.5f, sunAlt);
        int litBase = mix(WHITE, sunCol, tw * 0.75f);
        int shadeBase = mix(0xFF9DB8DE, rawMid, tw);
        cloudLit = mix(litBase, 0xFF5A6CB0, nightness);
        cloudShade = mix(shadeBase, 0xFF171E4C, nightness);
        cloudAlpha = lerp(0.95f, 0.55f, nightness) * (1f - 0.82f * a);
        birdCol = mix(rawMid, BLACK, 0.72f);

        // snow caps
        int snowDay = mix(WHITE, 0xFFDCE8FF, 0.5f);
        snowCol = mix(mix(snowDay, sunCol, tw * 0.65f), 0xFF7F93D6, nightness);
        snowAlpha = lerp(0.92f, 0.55f, nightness) * (1f - 0.55f * a);
        mwOuter = unitRadial(0xFF6F86E8, 0.9f, 0.30f);
        mwInner = unitRadial(0xFFCFC8FF, 0.9f, 0.25f);

        // charge visuals
        lineShader = new LinearGradient(0f, 0f, 1f, 0f, new int[]{alphaOf(chargeCol, 0f), alphaOf(chargeCol, 0.9f), alphaOf(chargeCol, 1f)},
                new float[]{0f, 0.75f, 1f}, Shader.TileMode.CLAMP);
        chargeHalo = unitRadial(chargeCol, 0.85f, 0.30f);
        int c0 = chargeCol;
        int c1 = mix(chargeCol, 0xFF35D0FF, 0.55f);
        int c2 = mix(chargeCol, 0xFFA78BFF, 0.62f);
        auroraShader[0] = auroraGrad(c0);
        auroraShader[1] = auroraGrad(c1);
        auroraShader[2] = auroraGrad(c2);
    }

    private Shader unitRadial(int col, float midA, float midStop) {
        return new RadialGradient(0f, 0f, 1f, new int[]{alphaOf(col, 1f), alphaOf(col, midA * 0.35f), alphaOf(col, 0f)},
                new float[]{0f, midStop, 1f}, Shader.TileMode.CLAMP);
    }

    private Shader auroraGrad(int col) {
        float hh = H * 0.20f;
        return new LinearGradient(0f, 0f, 0f, hh, new int[]{alphaOf(col, 0f), alphaOf(col, 0.95f), alphaOf(scaleRgb(col, 0.6f), 0.35f), alphaOf(col, 0f)},
                new float[]{0f, 0.22f, 0.58f, 1f}, Shader.TileMode.CLAMP);
    }

    private void aimLights() {
        sun.x = sunX + shX(0.05f);
        sun.y = sunY + shY(0.05f);
        moon.x = moonX + shX(0.05f);
        moon.y = moonY + shY(0.05f);
        aim(sun);
        aim(moon);
    }

    private void aim(Light l) {
        if (l.rim == null) return;
        tmpM.setScale(l.reach, l.reach);
        tmpM.postTranslate(l.x, l.y);
        l.rim.setLocalMatrix(tmpM);
        l.glow.setLocalMatrix(tmpM);
    }

    // ================================================================== parallax helpers
    private float shX(float d) {
        float v = (parX * 0.045f * W + (scroll - 0.5f) * 0.12f * W) * d * ampl;
        return clamp(v, -0.12f * W, 0.12f * W);
    }

    private float shY(float d) {
        float v = parY * 0.016f * H * d * ampl;
        return clamp(v, -0.03f * H, 0.03f * H);
    }

    // ================================================================== geometry builders
    private float hash(int n) {
        n = (n << 13) ^ n;
        return 1f - ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824f;
    }

    private float vnoise(float x, int seed) {
        int i = (int) Math.floor(x);
        float f = x - i;
        float a = hash(i * 17 + seed * 131);
        float b = hash((i + 1) * 17 + seed * 131);
        float t = f * f * (3f - 2f * f);
        return a + (b - a) * t;
    }

    private void buildLayer(Layer L) {
        Random r = new Random(L.seed * 7919L);
        float x0 = -0.14f * W, x1 = 1.14f * W, span = x1 - x0;
        int n = L.peaks;
        float cell = span / n;
        float[] px = new float[n], ph = new float[n], pw = new float[n];
        for (int i = 0; i < n; i++) {
            px[i] = x0 + (i + 0.5f + (r.nextFloat() - 0.5f) * 0.75f) * cell;
            ph[i] = 0.42f + 0.58f * r.nextFloat();
            pw[i] = cell * (0.85f + 0.95f * r.nextFloat());
        }
        ph[r.nextInt(n)] = 1f;
        int samples = 220;
        float[] xs = new float[samples + 1], ys = new float[samples + 1];
        L.fill.reset();
        L.ridge.reset();
        L.snow.reset();
        float overlap = 8f * dp;
        float top = waterY;
        float detailAmp = 0.16f * (1f - L.round * 0.5f);
        for (int s = 0; s <= samples; s++) {
            float x = x0 + span * s / samples;
            float hgt = 0f;
            for (int i = 0; i < n; i++) {
                float d = abs(x - px[i]) / pw[i];
                if (d < 1f) {
                    float tri = 1f - d;
                    float rolling = 0.5f * (1f + cos(PI * d));
                    float v = ph[i] * lerp(tri, rolling, L.round);
                    if (v > hgt) hgt = v;
                }
            }
            float detail = vnoise(x / (cell * 0.45f), L.seed) * 0.62f + vnoise(x / (cell * 0.17f), L.seed + 7) * 0.38f;
            hgt = clamp01(hgt + detail * detailAmp * (0.2f + hgt));
            float y = waterY - (L.base + L.amp * hgt) * H;
            xs[s] = x;
            ys[s] = y;
            if (y < top) top = y;
            if (s == 0) {
                L.fill.moveTo(x, waterY + overlap);
                L.fill.lineTo(x, y);
                L.ridge.moveTo(x, y);
            } else {
                L.fill.lineTo(x, y);
                L.ridge.lineTo(x, y);
            }
        }
        L.fill.lineTo(x1, waterY + overlap);
        L.fill.close();

        // little pines standing on the ridge (adds scale)
        for (int t = 0; t < L.treeCount; t++) {
            int idx = 4 + r.nextInt(samples - 8);
            float th = L.treeH * H * (0.7f + 0.7f * r.nextFloat());
            addFir(L.fill, xs[idx], ys[idx] + 0.004f * H, th, th * 0.50f);
            if (ys[idx] - th < top) top = ys[idx] - th;
        }

        // snow caps on the tall summits
        if (L.capDepth > 0f) {
            float tallest = waterY - top;
            for (int s = 3; s < samples - 3; s++) {
                float y = ys[s];
                if (!(y <= ys[s - 1] && y <= ys[s + 1] && y <= ys[s - 2] && y <= ys[s + 2] && y <= ys[s - 3] && y <= ys[s + 3])) continue;
                float height = waterY - y;
                if (height < 0.62f * tallest) continue;
                float depth = L.capDepth * (height - L.base * H * 0.4f);
                if (depth < 6f * dp) continue;
                float hw = depth * 2.1f;
                int lo = s, hi = s;
                while (lo > 0 && xs[s] - xs[lo - 1] < hw && ys[lo - 1] < y + depth) lo--;
                while (hi < samples && xs[hi + 1] - xs[s] < hw && ys[hi + 1] < y + depth) hi++;
                if (hi - lo < 4) continue;
                L.snow.moveTo(xs[lo], ys[lo]);
                for (int k = lo + 1; k <= hi; k++) L.snow.lineTo(xs[k], ys[k]);
                for (int k = hi; k >= lo; k--) {
                    float tp = 1f - abs(xs[k] - xs[s]) / hw;
                    if (tp < 0f) tp = 0f;
                    float thick = depth * pow(tp, 0.8f) * (((k / 3) & 1) == 0 ? 1f : 0.58f);
                    L.snow.lineTo(xs[k], ys[k] + thick);
                }
                L.snow.close();
                s = hi;
            }
        }
        L.topY = top;
    }

    private float landY(float x) {
        float u = x / W;
        float left = H * 0.082f * (float) Math.exp(-((u - 0.02f) * (u - 0.02f)) / 0.045f);
        float right = H * 0.060f * (float) Math.exp(-((u - 1.0f) * (u - 1.0f)) / 0.040f);
        float ripple = H * 0.004f * sin(u * 11f) + H * 0.003f * sin(u * 23f + 1.3f);
        return H * 0.918f - left - right + ripple;
    }

    private void addFir(Path p, float cx, float baseY, float h, float w) {
        int tiers = 4;
        float trunk = w * 0.06f;
        float topY = baseY - h;
        float lean = (hash((int) (cx * 3f)) * 0.5f) * w * 0.06f;
        p.moveTo(cx + lean, topY);
        for (int i = 1; i <= tiers; i++) {
            float f = i / (float) tiers;
            float yi = topY + h * 0.90f * f;
            float hw = w * 0.5f * (0.28f + 0.72f * f);
            p.lineTo(cx + hw, yi);
            if (i < tiers) p.lineTo(cx + hw * 0.40f, yi - h * 0.012f);
        }
        p.lineTo(cx + trunk, topY + h * 0.90f);
        p.lineTo(cx + trunk, baseY);
        p.lineTo(cx - trunk, baseY);
        p.lineTo(cx - trunk, topY + h * 0.90f);
        for (int i = tiers; i >= 1; i--) {
            float f = i / (float) tiers;
            float yi = topY + h * 0.90f * f;
            float hw = w * 0.5f * (0.28f + 0.72f * f);
            p.lineTo(cx - hw, yi);
            if (i > 1) {
                float f2 = (i - 1) / (float) tiers;
                float yj = topY + h * 0.90f * f2;
                float hw2 = w * 0.5f * (0.28f + 0.72f * f2);
                p.lineTo(cx - hw2 * 0.40f, yj - h * 0.012f);
            }
        }
        p.close();
    }

    private void buildForeground() {
        landFill.reset();
        landRidge.reset();
        float x0 = -0.15f * W, x1 = 1.15f * W;
        int n = 90;
        landFill.moveTo(x0, H * 1.04f);
        for (int s = 0; s <= n; s++) {
            float x = x0 + (x1 - x0) * s / n;
            float y = landY(x);
            landFill.lineTo(x, y);
            if (s == 0) landRidge.moveTo(x, y); else landRidge.lineTo(x, y);
        }
        landFill.lineTo(x1, H * 1.04f);
        landFill.close();

        treeBase = H * 0.93f;
        Random r = new Random(77L);
        float[] lx = {-0.04f, 0.015f, 0.075f, 0.135f, 0.20f, 0.265f, 0.33f};
        float[] lh = {0.235f, 0.175f, 0.215f, 0.135f, 0.165f, 0.100f, 0.078f};
        buildTrees(treesL, lx, lh, r);
        float[] rx = {1.04f, 0.985f, 0.925f, 0.865f, 0.80f, 0.745f};
        float[] rh = {0.205f, 0.150f, 0.185f, 0.112f, 0.085f, 0.065f};
        buildTrees(treesR, rx, rh, r);
    }

    /** Builds one Path per tree, smallest (farthest) first so bigger trees overlap them. */
    private void buildTrees(Path[] out, float[] xf, float[] hf, Random r) {
        int n = out.length;
        int[] order = new int[n];
        for (int i = 0; i < n; i++) order[i] = i;
        for (int i = 1; i < n; i++) {
            int v = order[i];
            int j = i - 1;
            while (j >= 0 && hf[order[j]] > hf[v]) { order[j + 1] = order[j]; j--; }
            order[j + 1] = v;
        }
        for (int k = 0; k < n; k++) {
            int i = order[k];
            out[k].reset();
            float cx = xf[i] * W + (r.nextFloat() - 0.5f) * 0.015f * W;
            float h = hf[i] * H;
            addFir(out[k], cx, landY(cx) + 0.012f * H, h, h * 0.46f);
        }
    }

    private void buildAmbient() {
        Random r = new Random(11L);
        // stars (first 95 hug a diagonal milky-way band)
        float ax = -0.05f * W, ay = 0.80f * waterY, bx = 1.05f * W, by = 0.04f * waterY;
        float dx = bx - ax, dy = by - ay;
        float len = sqrt(dx * dx + dy * dy);
        float nx = -dy / len, ny = dx / len;
        for (int i = 0; i < NSTAR; i++) {
            if (i < 95) {
                float t = r.nextFloat();
                float off = (float) r.nextGaussian() * 0.055f * W;
                stX[i] = ax + dx * t + nx * off;
                stY[i] = ay + dy * t + ny * off;
            } else {
                stX[i] = (-0.05f + 1.1f * r.nextFloat()) * W;
                stY[i] = r.nextFloat() * waterY * 0.92f;
            }
            float b = r.nextFloat();
            stB[i] = 0.25f + 0.75f * b * b;
            stR[i] = (0.42f + 0.9f * b * b * b) * dp * (i % 29 == 0 ? 1.7f : 1f);
            stP[i] = r.nextFloat() * TAU;
            stS[i] = 0.6f + 2.2f * r.nextFloat();
        }
        // streaks
        for (int i = 0; i < NSTREAK; i++) {
            sX[i] = r.nextFloat() * 1.4f;
            sY[i] = waterY * (0.62f + 0.30f * r.nextFloat()) ;
            sLen[i] = W * (0.30f + 0.35f * r.nextFloat());
            sSp[i] = 0.002f + 0.003f * r.nextFloat();
        }
        for (int i = 0; i < NC; i++) cOff[i] = 0f;
        flockX = -0.2f * W;
        flockY = waterY * 0.30f;
        for (int i = 0; i < NFF; i++) {
            ffX[i] = r.nextFloat() * W;
            ffY[i] = H * (0.70f + 0.23f * r.nextFloat());
            ffP[i] = r.nextFloat() * TAU;
            ffS[i] = 0.5f + r.nextFloat();
        }
        for (int i = 0; i < NRIP; i++) {
            float t = r.nextFloat();
            rpY[i] = waterY + (0.012f + pow(t, 1.5f) * 0.33f) * H;
            rpX[i] = r.nextFloat() * W;
            rpL[i] = (6f + 24f * r.nextFloat()) * dp * (0.5f + 1.5f * t);
            rpP[i] = r.nextFloat() * TAU;
        }
        for (int i = 0; i < NTAP; i++) tapT[i] = -1f;
        for (int i = 0; i < NMOTE; i++) mL[i] = 0f;
    }

    // ================================================================== rendering
    private void halo(Canvas c, Shader sh, float x, float y, float rx, float ry, float alpha) {
        if (sh == null || alpha <= 0.004f) return;
        pGrad.setShader(sh);
        pGrad.setAlpha((int) (clamp01(alpha) * 255f));
        c.save();
        c.translate(x, y);
        c.scale(rx, ry);
        c.drawCircle(0f, 0f, 1f, pGrad);
        c.restore();
    }

    private void disc(Canvas c, float x, float y, float r, int color) {
        pFill.setShader(null);
        pFill.setColor(color);
        c.drawCircle(x, y, r, pFill);
    }

    private float lightBoost() {
        return 1f + 0.35f * chg * (0.5f + 0.5f * sin(time * 2.2f)) + 0.9f * unlockP;
    }

    private void render(Canvas c) {
        c.drawColor(BLACK);

        drawSky(c);
        drawStars(c);
        drawAurora(c);
        drawMoon(c, false);
        drawSun(c, false);
        drawStreaks(c);
        drawClouds(c);
        drawBirds(c);
        drawMountains(c, false);
        drawWater(c);
        drawMist(c);
        drawForeground(c);
        drawFireflies(c);
        drawChargeFx(c);
        drawOverlays(c);
    }

    private void drawSky(Canvas c) {
        pGrad.setShader(skyShader);
        pGrad.setAlpha(255);
        c.drawRect(-2f, -0.05f * H, W + 2f, waterY + 2f, pGrad);
    }

    // ------------------------------------------------------------------ stars & shooting star
    private void drawStars(Canvas c) {
        float a = starAlpha * (1f + 0.25f * amoledMix);
        if (a < 0.01f) return;
        float sx = shX(0.02f), sy = shY(0.02f);

        // milky-way: soft rotated glows
        float ax = -0.05f * W + sx, ay = 0.80f * waterY + sy, bx = 1.05f * W + sx, by = 0.04f * waterY + sy;
        float mdx = bx - ax, mdy = by - ay;
        float mlen = sqrt(mdx * mdx + mdy * mdy);
        float ang = (float) Math.toDegrees(Math.atan2(mdy, mdx));
        float ma = a * (1f - 0.35f * amoledMix);
        c.save();
        c.translate((ax + bx) * 0.5f, (ay + by) * 0.5f);
        c.rotate(ang);
        halo(c, mwOuter, 0f, 0f, mlen * 0.58f, 0.17f * W, 0.20f * ma);
        halo(c, mwInner, 0f, 0f, mlen * 0.50f, 0.075f * W, 0.17f * ma);
        c.restore();

        for (int i = 0; i < NSTAR; i++) {
            float tw = 0.62f + 0.38f * sin(time * stS[i] + stP[i]);
            float al = a * stB[i] * tw;
            if (al < 0.02f) continue;
            float x = stX[i] + sx, y = stY[i] + sy;
            disc(c, x, y, stR[i], alphaOf(0xFFEAF0FF, al));
            if (stR[i] > 1.3f * dp) {
                pStroke.setStrokeWidth(0.7f * dp);
                pStroke.setColor(alphaOf(0xFFEAF0FF, al * 0.55f));
                float s = stR[i] * 3.2f;
                c.drawLine(x - s, y, x + s, y, pStroke);
                c.drawLine(x, y - s, x, y + s, pStroke);
            }
        }

        if (ssT >= 0f) {
            float u = clamp01(ssT / 0.9f);
            float dist = 0.38f * W * u;
            float hx = ssX + ssDx * dist + sx, hy = ssY + ssDy * dist + sy;
            float tail = Math.min(0.20f * W, dist);
            float fade = (1f - u) * a;
            pStroke.setStrokeWidth(1.6f * dp);
            int segs = 8;
            for (int k = 0; k < segs; k++) {
                float f0 = k / (float) segs, f1 = (k + 1) / (float) segs;
                float x0 = hx - ssDx * tail * (1f - f0), y0 = hy - ssDy * tail * (1f - f0);
                float x1 = hx - ssDx * tail * (1f - f1), y1 = hy - ssDy * tail * (1f - f1);
                pStroke.setColor(alphaOf(0xFFFFFFFF, fade * f1 * 0.95f));
                c.drawLine(x0, y0, x1, y1, pStroke);
            }
            disc(c, hx, hy, 1.8f * dp, alphaOf(0xFFFFFFFF, fade));
        }
    }

    // ------------------------------------------------------------------ aurora (charging)
    private void drawAurora(Canvas c) {
        float k = chg * nightness;
        if (!cfg.charging || k < 0.02f) return;
        float hh = H * 0.20f;
        int n = 38;
        float step = (W * 1.2f) / n;
        float rw = step * 1.3f;
        float sx = shX(0.03f), sy = shY(0.03f);
        for (int b = 0; b < 3; b++) {
            float baseY = H * (0.17f + 0.07f * b);
            pGrad.setShader(auroraShader[b]);
            for (int i = 0; i < n; i++) {
                float ph = i * 0.33f + b * 2.1f;
                float yTop = baseY + H * (0.030f * sin(ph * 0.8f + time * 0.55f + b) + 0.018f * sin(i * 0.13f - time * 0.4f));
                float hgt = hh * (0.65f + 0.35f * sin(ph + time * 0.9f));
                float al = k * (0.30f + 0.28f * sin(i * 0.21f + time * 0.8f + b * 1.7f));
                if (al <= 0.01f) continue;
                pGrad.setAlpha((int) (clamp01(al) * 255f));
                c.save();
                c.translate(-0.1f * W + i * step + sx, yTop + sy);
                c.scale(1f, hgt / hh);
                c.drawRect(0f, 0f, rw, hh, pGrad);
                c.restore();
            }
        }
    }

    // ------------------------------------------------------------------ sun
    private void drawSun(Canvas c, boolean mirrored) {
        if (sunAlt < -0.18f) return;
        float vis = smooth(-0.18f, -0.02f, sunAlt);
        float alt01 = clamp01(sunAlt);
        float x = sunX + shX(0.05f), y = sunY + shY(0.05f);
        float r = W * (0.056f + 0.024f * (1f - alt01));
        float boost = lightBoost();

        // god rays (low sun)
        float rayAmt = smooth(0.45f, 0.04f, sunAlt) * vis;
        if (!mirrored && rayAmt > 0.02f) {
            c.save();
            c.translate(x, y);
            pGrad.setShader(rayShader);
            float R = H * 1.25f;
            for (int k = 0; k < 9; k++) {
                float ang = -PI * (0.04f + 0.92f * k / 8f) + 0.06f * sin(time * 0.15f + k * 1.7f);
                float wd = 0.055f + 0.025f * sin(k * 2.3f + time * 0.2f);
                pGrad.setAlpha((int) (clamp01(0.15f * rayAmt * (0.55f + 0.45f * sin(time * 0.5f + k * 1.9f))) * 255f));
                tmpPath.reset();
                tmpPath.moveTo(0f, 0f);
                tmpPath.lineTo(cos(ang - wd) * R, sin(ang - wd) * R);
                tmpPath.lineTo(cos(ang + wd) * R, sin(ang + wd) * R);
                tmpPath.close();
                c.drawPath(tmpPath, pGrad);
            }
            c.restore();
        }

        halo(c, sunHalo, x, y, W * 1.15f, W * 1.15f, 0.62f * vis * (1f - 0.35f * alt01) * (1f - 0.55f * amoledMix) * boost);
        if (!mirrored) {
            float bl = smooth(0.50f, 0.02f, sunAlt) * vis;
            halo(c, bloomShader, x, Math.min(y + r * 0.6f, sunHorY + 0.02f * H), W * 1.0f, H * 0.13f, 0.75f * bl * boost);
        }
        disc(c, x, y, r * 2.25f, alphaOf(sunCol, 0.07f * vis));
        disc(c, x, y, r * 1.65f, alphaOf(sunCol, 0.12f * vis));
        disc(c, x, y, r * 1.28f, alphaOf(sunCol, 0.22f * vis));
        disc(c, x, y, r, alphaOf(mix(sunCol, WHITE, 0.45f), vis));
        disc(c, x, y, r * 0.72f, alphaOf(mix(sunCol, WHITE, 0.85f), 0.92f * vis));
    }

    // ------------------------------------------------------------------ moon (real phase)
    private void drawMoon(Canvas c, boolean mirrored) {
        if (!moonUp) return;
        float vis = smooth(0.25f, -0.15f, sunAlt);
        if (vis < 0.01f) return;
        float x = moonX + shX(0.05f), y = moonY + shY(0.05f);
        float r = W * 0.050f;
        float boost = lightBoost();
        float gl = (0.30f + 0.70f * illum);

        halo(c, moonHalo, x, y, W * 0.85f, W * 0.85f, 0.50f * vis * gl * (1f - 0.5f * amoledMix) * boost);
        disc(c, x, y, r * 2.0f, alphaOf(MOON_GLOW, 0.05f * vis * gl));
        disc(c, x, y, r * 1.45f, alphaOf(MOON_GLOW, 0.09f * vis * gl));
        // dark side (earthshine)
        disc(c, x, y, r, alphaOf(0xFF1D2650, 0.80f * vis));

        float q = moonPhase < 0.5f ? moonPhase : 1f - moonPhase;     // 0..0.5
        if (q < 0.012f) return;                                       // new moon
        float k = cos(TAU * q);
        float a = abs(k) * r;
        moonPath.reset();
        moonPath.arcTo(x - r, y - r, x + r, y + r, -90f, 180f, true);
        if (q < 0.25f) moonPath.arcTo(x - a, y - r, x + a, y + r, 90f, -180f, false);
        else moonPath.arcTo(x - a, y - r, x + a, y + r, 90f, 180f, false);
        moonPath.close();

        c.save();
        if (moonPhase > 0.5f) c.scale(-1f, 1f, x, y);
        pFill.setShader(null);
        pFill.setColor(alphaOf(MOON_COL, vis));
        c.drawPath(moonPath, pFill);
        c.clipPath(moonPath);
        int mare = alphaOf(0xFF8793C2, 0.50f * vis);
        disc(c, x - 0.30f * r, y - 0.22f * r, 0.30f * r, mare);
        disc(c, x + 0.26f * r, y - 0.06f * r, 0.22f * r, mare);
        disc(c, x - 0.04f * r, y + 0.38f * r, 0.26f * r, mare);
        disc(c, x + 0.38f * r, y + 0.40f * r, 0.13f * r, mare);
        disc(c, x - 0.45f * r, y + 0.12f * r, 0.11f * r, mare);
        c.restore();
    }

    // ------------------------------------------------------------------ twilight strata
    private void drawStreaks(Canvas c) {
        float tw = smooth(0.40f, 0.08f, sunAlt) * smooth(-0.30f, -0.04f, sunAlt);
        float al = tw * 0.55f * (1f - 0.8f * amoledMix) + 0.05f * dayness * (1f - amoledMix);
        if (al < 0.02f) return;
        int col = mix(sunCol, rawMid, 0.45f);
        pFill.setShader(null);
        for (int i = 0; i < NSTREAK; i++) {
            float wx = ((sX[i] * W + time * sSp[i] * W) % (1.5f * W)) - 0.25f * W + shX(0.12f);
            float y = sY[i] + shY(0.12f);
            float h = (2.2f + 1.6f * (i % 3)) * dp;
            pFill.setColor(alphaOf(col, al * (0.55f + 0.15f * i)));
            c.drawRoundRect(wx, y, wx + sLen[i], y + h, h * 0.5f, h * 0.5f, pFill);
        }
    }

    // ------------------------------------------------------------------ clouds (cel-shaded)
    private void drawCloudShape(Canvas c, float x, float baseY, float s, float ox, float oy, float shrink, int color, boolean withBase) {
        pFill.setShader(null);
        pFill.setColor(color);
        for (int p = 0; p < PUFF_DX.length; p++) {
            float rr = PUFF_R[p] * s * shrink;
            c.drawCircle(x + PUFF_DX[p] * s + ox, baseY - PUFF_R[p] * s + oy, rr, pFill);
        }
        if (withBase) {
            c.drawRoundRect(x - 1.35f * s, baseY - 0.34f * s, x + 1.55f * s, baseY, 0.17f * s, 0.17f * s, pFill);
        }
    }

    private void drawClouds(Canvas c) {
        if (!cfg.clouds || cloudAlpha < 0.03f) return;
        Light lt = sun.strength >= moon.strength ? sun : moon;
        float worldW = 1.5f * W;
        for (int i = 0; i < NC; i++) {
            float wx = ((C_CX[i] * worldW + cOff[i]) % worldW) - 0.25f * W + shX(C_DP[i]);
            float by = C_CY[i] * waterY + shY(C_DP[i]);
            float s = C_SZ[i] * W;
            float dx = lt.x - wx, dy = lt.y - by;
            float dl = sqrt(dx * dx + dy * dy) + 1f;
            float ox = dx / dl * 0.12f * s, oy = dy / dl * 0.10f * s - 0.03f * s;
            drawCloudShape(c, wx, by, s, 0f, 0f, 1f, alphaOf(cloudShade, cloudAlpha), true);
            drawCloudShape(c, wx, by, s, ox, oy, 0.84f, alphaOf(cloudLit, cloudAlpha), false);
        }
    }

    // ------------------------------------------------------------------ birds
    private void drawBirds(Canvas c) {
        if (!cfg.life) return;
        float a = dayness * 0.85f * (1f - amoledMix);
        if (a < 0.05f) return;
        pStroke.setShader(null);
        pStroke.setStrokeWidth(1.5f * dp);
        pStroke.setColor(alphaOf(birdCol, a));
        float sx = shX(0.12f), sy = shY(0.12f);
        for (int i = 0; i < B_DX.length; i++) {
            float bx = flockX + B_DX[i] * W * 2.2f + sx;
            float by = flockY + B_DY[i] * H + sy;
            float s = (5f + 1.8f * (i % 3)) * dp;
            float f = sin(time * 8f + i * 1.3f);
            birdPath.reset();
            birdPath.moveTo(bx - s, by + f * s * 0.55f);
            birdPath.quadTo(bx - s * 0.5f, by - s * 0.40f, bx, by);
            birdPath.quadTo(bx + s * 0.5f, by - s * 0.40f, bx + s, by + f * s * 0.55f);
            c.drawPath(birdPath, pStroke);
        }
    }

    // ------------------------------------------------------------------ mountains
    private void drawMountains(Canvas c, boolean mirrored) {
        for (int i = 0; i < NL; i++) {
            Layer L = layers[i];
            c.save();
            c.translate(shX(L.depth), shY(L.depth));
            if (zoom > 0.0005f) {
                float sc = 1f + zoom * L.depth;
                c.scale(sc, sc, W * 0.5f, waterY);
            }
            pGrad.setShader(L.fillShader);
            pGrad.setAlpha(255);
            c.drawPath(L.fill, pGrad);

            if (L.capDepth > 0f && snowAlpha > 0.02f) {
                pFill.setShader(null);
                pFill.setColor(alphaOf(snowCol, snowAlpha * (1f - 0.35f * L.fog)));
                c.drawPath(L.snow, pFill);
                for (int q = 0; q < 2; q++) {
                    Light lq = q == 0 ? sun : moon;
                    if (lq.strength < 0.02f || lq.rim == null) continue;
                    pGrad.setShader(lq.rim);
                    pGrad.setAlpha((int) (clamp01(0.85f * lq.strength) * 255f));
                    c.drawPath(L.snow, pGrad);
                }
            }

            glowAndRim(c, sun, L, mirrored);
            glowAndRim(c, moon, L, mirrored);
            c.restore();
        }
    }

    private void glowAndRim(Canvas c, Light l, Layer L, boolean mirrored) {
        if (l.strength < 0.02f || l.glow == null) return;
        float k = l.strength * (1f - 0.25f * amoledMix);
        pGrad.setShader(l.glow);
        pGrad.setAlpha((int) (clamp01(0.55f * k * (1f - L.tone * 0.45f)) * 255f));
        c.drawPath(L.fill, pGrad);
        if (!mirrored) {
            pGrad.setShader(null);
            pStroke.setShader(l.rim);
            pStroke.setStrokeWidth(5f * dp);
            pStroke.setColor(alphaOf(WHITE, clamp01(0.20f * k)));
            c.drawPath(L.ridge, pStroke);
            pStroke.setStrokeWidth(1.5f * dp * (0.7f + 0.5f * L.depth));
            pStroke.setColor(alphaOf(WHITE, clamp01(0.95f * k)));
            c.drawPath(L.ridge, pStroke);
            pStroke.setShader(null);
        }
    }

    // ------------------------------------------------------------------ lake
    private void drawWater(Canvas c) {
        c.save();
        c.clipRect(0f, waterY, W, H + 2f);
        // mirrored world
        c.translate(0f, waterY);
        c.scale(1f, -1f);
        c.translate(0f, -waterY);
        drawSky(c);
        drawMoon(c, true);
        drawSun(c, true);
        drawClouds(c);
        drawMountains(c, true);
        c.restore();

        // water tint / depth
        pGrad.setShader(waterShader);
        pGrad.setAlpha(255);
        c.drawRect(0f, waterY, W, H + 2f, pGrad);

        // ripples
        float ra = 0.03f + 0.022f * dayness;
        int rc = mix(skyHor, WHITE, 0.55f);
        pFill.setShader(null);
        for (int i = 0; i < NRIP; i++) {
            float x = ((rpX[i] + sin(time * 0.35f + rpP[i]) * 14f * dp) % (W + 80f * dp)) - 40f * dp + shX(0.6f);
            float al = ra * (0.6f + 0.4f * sin(time * 1.1f + rpP[i] * 3f));
            pFill.setColor(alphaOf(rc, al * (1f - 0.7f * amoledMix)));
            float h = 1.2f * dp;
            c.drawRoundRect(x, rpY[i], x + rpL[i], rpY[i] + h, h, h, pFill);
        }

        // sun / moon glitter
        if (sunAlt > -0.04f) glitter(c, sun.x, smooth(-0.04f, 0.10f, sunAlt) * (1f - 0.45f * clamp01(sunAlt)), mix(sunCol, WHITE, 0.4f));
        if (moonUp) glitter(c, moon.x, moon.strength * 0.9f, MOON_COL);

        // tap ripples
        pStroke.setShader(null);
        for (int i = 0; i < NTAP; i++) {
            if (tapT[i] < 0f) continue;
            float u = tapT[i] / 3f;
            float rr = (10f + 150f * (1f - (1f - u) * (1f - u))) * dp;
            pStroke.setStrokeWidth(1.6f * dp);
            pStroke.setColor(alphaOf(WHITE, 0.45f * (1f - u) * (1f - 0.5f * amoledMix)));
            c.drawOval(tapX[i] - rr, tapY[i] - rr * 0.28f, tapX[i] + rr, tapY[i] + rr * 0.28f, pStroke);
            if (u > 0.12f) {
                float r2 = rr * 0.62f;
                pStroke.setColor(alphaOf(WHITE, 0.28f * (1f - u)));
                c.drawOval(tapX[i] - r2, tapY[i] - r2 * 0.28f, tapX[i] + r2, tapY[i] + r2 * 0.28f, pStroke);
            }
        }
    }

    private void glitter(Canvas c, float lx, float strength, int col) {
        if (strength < 0.03f) return;
        pFill.setShader(null);
        int n = 22;
        for (int k = 0; k < n; k++) {
            float t = (k + 0.5f) / n;
            float y = waterY + H * (0.012f + 0.30f * t * t);
            float w = (10f + 150f * t) * dp * (0.45f + 0.55f * (0.5f + 0.5f * sin(time * 1.7f + k * 2.3f)));
            float off = sin(time * 0.8f + k * 1.9f) * (6f + 20f * t) * dp;
            float al = strength * (0.85f - 0.55f * t) * (0.35f + 0.65f * (0.5f + 0.5f * sin(time * 2.6f + k * 4.1f)));
            float h = (1.6f + 2.2f * t) * dp;
            pFill.setColor(alphaOf(col, al));
            c.drawRoundRect(lx + off - w * 0.5f, y, lx + off + w * 0.5f, y + h, h * 0.5f, h * 0.5f, pFill);
        }
    }

    private void drawMist(Canvas c) {
        pGrad.setShader(mistShader);
        pGrad.setAlpha(255);
        float mistH = H * 0.075f;
        c.drawRect(0f, waterY - mistH, W, waterY + mistH, pGrad);
    }

    // ------------------------------------------------------------------ foreground
    private void rimStroke(Canvas c, Light l, Path p, float widthDp, float amt) {
        if (l.strength < 0.02f || l.rim == null) return;
        float k = l.strength * amt;
        pStroke.setShader(l.rim);
        pStroke.setStrokeWidth(widthDp * dp);
        pStroke.setColor(alphaOf(WHITE, clamp01(k)));
        c.drawPath(p, pStroke);
        pStroke.setShader(null);
    }

    private void drawForeground(Canvas c) {
        c.save();
        c.translate(shX(1f), shY(1f));
        if (zoom > 0.0005f) {
            float sc = 1f + zoom;
            c.scale(sc, sc, W * 0.5f, H);
        }
        pFill.setShader(null);
        pFill.setColor(foreCol);

        float swayL = 0.012f * sin(time * 0.9f) + 0.006f * sin(time * 2.3f + 1f);
        float swayR = 0.012f * sin(time * 0.8f + 2f) + 0.006f * sin(time * 2.1f + 0.4f);
        float rimAmt = 0.55f;

        drawTrees(c, treesL, swayL, rimAmt);
        drawTrees(c, treesR, swayR, rimAmt);

        pFill.setShader(null);
        pFill.setColor(foreCol);
        c.drawPath(landFill, pFill);
        rimStroke(c, sun, landRidge, 1.6f, rimAmt);
        rimStroke(c, moon, landRidge, 1.6f, rimAmt);
        c.restore();
    }

    private void drawTrees(Canvas c, Path[] trees, float sway, float rimAmt) {
        c.save();
        c.translate(0f, treeBase);
        c.skew(sway, 0f);
        c.translate(0f, -treeBase);
        for (int i = 0; i < trees.length; i++) {
            pFill.setShader(null);
            pFill.setColor(foreCol);
            c.drawPath(trees[i], pFill);
            rimStroke(c, sun, trees[i], 1.4f, rimAmt);
            rimStroke(c, moon, trees[i], 1.4f, rimAmt);
        }
        c.restore();
    }

    // ------------------------------------------------------------------ fireflies
    private void drawFireflies(Canvas c) {
        if (!cfg.life) return;
        float a = smooth(0.12f, -0.15f, sunAlt);
        if (a < 0.03f) return;
        for (int i = 0; i < NFF; i++) {
            float x = ffX[i] + sin(time * 0.31f * ffS[i] + ffP[i]) * 0.045f * W + shX(0.9f);
            float y = ffY[i] + sin(time * 0.43f * ffS[i] + ffP[i] * 1.7f) * 0.018f * H + shY(0.9f);
            float pulse = 0.5f + 0.5f * sin(time * (0.9f + ffS[i]) + ffP[i] * 3f);
            pulse = pulse * pulse;
            float al = a * pulse;
            if (al < 0.03f) continue;
            disc(c, x, y, 7f * dp, alphaOf(0xFFD6FF7A, 0.10f * al));
            disc(c, x, y, 3.2f * dp, alphaOf(0xFFE4FF9A, 0.26f * al));
            disc(c, x, y, 1.4f * dp, alphaOf(0xFFF8FFD0, al));
        }
    }

    // ------------------------------------------------------------------ charging FX
    private void drawChargeFx(Canvas c) {
        if (!cfg.charging) return;
        if (chg > 0.01f) {
            float len = W * clamp(level, 0.03f, 1f);
            float pul = 0.65f + 0.35f * sin(time * 2.4f);
            pGrad.setShader(lineShader);
            c.save();
            c.translate(0f, waterY);
            c.scale(len, 1f);
            pGrad.setAlpha((int) (clamp01(0.28f * chg * pul) * 255f));
            c.drawRect(0f, -6f * dp, 1f, 6f * dp, pGrad);
            pGrad.setAlpha((int) (clamp01(chg * pul) * 255f));
            c.drawRect(0f, -1.3f * dp, 1f, 1.3f * dp, pGrad);
            c.restore();
            halo(c, chargeHalo, len, waterY, 22f * dp, 22f * dp, 0.9f * chg * pul);
            disc(c, len, waterY, 2.4f * dp, alphaOf(WHITE, chg));

            // rising motes
            for (int i = 0; i < NMOTE; i++) {
                if (mL[i] <= 0f) continue;
                float life = clamp01(mL[i]);
                float al = sin(PI * life) * chg;
                if (al < 0.02f) continue;
                float x = mX[i] + shX(0.8f);
                disc(c, x, mY[i], mS[i] * dp * 3.2f, alphaOf(chargeCol, 0.16f * al));
                disc(c, x, mY[i], mS[i] * dp, alphaOf(mix(chargeCol, WHITE, 0.5f), 0.95f * al));
            }
        }
        if (pulseT >= 0f) {
            pStroke.setShader(null);
            for (int k = 0; k < 3; k++) {
                float u = (pulseT - k * 0.24f) / 1.7f;
                if (u <= 0f || u >= 1f) continue;
                float e = 1f - (1f - u) * (1f - u);
                float rr = e * H * 1.15f;
                pStroke.setStrokeWidth((2.5f + 12f * u) * dp);
                pStroke.setColor(alphaOf(chargeCol, 0.65f * (1f - u) * (1f - u * 0.3f)));
                c.drawCircle(W * 0.5f, H * 0.78f, rr, pStroke);
            }
        }
    }

    // ------------------------------------------------------------------ unlock / wake / vignette
    private void streak(Canvas c, Shader sh, float cx, float cy, float halfW, float h, float alpha) {
        if (alpha <= 0.01f) return;
        pGrad.setShader(sh);
        pGrad.setAlpha((int) (clamp01(alpha) * 255f));
        c.save();
        c.translate(cx - halfW, cy - h * 0.5f);
        c.scale(2f * halfW, h);
        c.drawRect(0f, 0f, 1f, 1f, pGrad);
        c.restore();
    }

    private void drawOverlays(Canvas c) {
        if (unlockP > 0.01f) {
            Light lt = sun.strength >= moon.strength ? sun : moon;
            boolean isSun = lt == sun;
            float lx = lt.x, ly = lt.y;
            if (isSun ? sunAlt < -0.15f : !moonUp) { lx = W * 0.5f; ly = waterY - 0.15f * H; }
            Shader sh = isSun ? sunHalo : moonHalo;
            halo(c, sh, lx, ly, W * 1.5f, W * 1.5f, 0.55f * unlockP);
            // anamorphic lens streak through the light source
            Shader st = isSun ? streakSun : streakMoon;
            halo(c, isSun ? sunHalo : moonHalo, lx, ly, W * (0.35f + 0.75f * unlockP), H * 0.006f * (1f + 1.5f * unlockP), 0.95f * unlockP);
            // a gleam running along the horizon
            float u = clamp01(unlockT / 1.9f);
            float gx = lerp(-0.25f * W, 1.25f * W, u);
            streak(c, st, gx, waterY, 0.35f * W, 3.2f * dp, 0.9f * unlockP);
        }
        pGrad.setShader(vignetteShader);
        pGrad.setAlpha(255);
        c.drawRect(0f, 0f, W, H, pGrad);

        if (wakeP > 0.01f) {
            pFill.setShader(null);
            pFill.setColor(alphaOf(BLACK, 0.55f * wakeP));
            c.drawRect(0f, 0f, W, H, pFill);
        }
    }
}
