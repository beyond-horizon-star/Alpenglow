package com.alpenglow.live;

import android.content.SharedPreferences;

/** Plain settings snapshot shared by the wallpaper engine, the in-app preview and the renderer. */
final class Settings {
    static final String PREFS = "alpenglow_prefs";

    static final String K_AMOLED = "amoled";        // 0 off, 1 night only, 2 always
    static final String K_PARALLAX = "parallax";    // boolean
    static final String K_PARALLAX_PCT = "parallax_pct";
    static final String K_CHARGING = "charging_fx";
    static final String K_UNLOCK = "unlock_fx";
    static final String K_LIFE = "life";            // birds, fireflies, shooting stars
    static final String K_CLOUDS = "clouds";
    static final String K_FPS = "fps";              // 15 / 30 / 60
    static final String K_SUNRISE = "sunrise_min";
    static final String K_SUNSET = "sunset_min";

    int amoled = 1;
    boolean parallax = true;
    int parallaxPct = 100;
    boolean charging = true;
    boolean unlock = true;
    boolean life = true;
    boolean clouds = true;
    int fps = 30;
    int sunriseMin = 390;   // 06:30
    int sunsetMin = 1110;   // 18:30

    void load(SharedPreferences sp) {
        amoled = clampInt(sp.getInt(K_AMOLED, 1), 0, 2);
        parallax = sp.getBoolean(K_PARALLAX, true);
        parallaxPct = clampInt(sp.getInt(K_PARALLAX_PCT, 100), 20, 200);
        charging = sp.getBoolean(K_CHARGING, true);
        unlock = sp.getBoolean(K_UNLOCK, true);
        life = sp.getBoolean(K_LIFE, true);
        clouds = sp.getBoolean(K_CLOUDS, true);
        int f = sp.getInt(K_FPS, 30);
        fps = (f <= 15) ? 15 : (f >= 60 ? 60 : 30);
        sunriseMin = clampInt(sp.getInt(K_SUNRISE, 390), 180, 600);
        sunsetMin = clampInt(sp.getInt(K_SUNSET, 1110), 960, 1380);
    }

    static int clampInt(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
