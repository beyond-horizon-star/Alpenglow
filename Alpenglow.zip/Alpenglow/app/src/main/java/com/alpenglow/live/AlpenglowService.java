package com.alpenglow.live;

import android.app.WallpaperColors;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.util.Log;
import android.view.Choreographer;
import android.view.SurfaceHolder;

/**
 * Alpenglow live wallpaper.
 *
 * Stability rules this class follows:
 *  - all drawing, sensor and broadcast callbacks run on ONE dedicated render thread (no locks needed)
 *  - nothing is drawn unless the wallpaper is visible AND the surface exists
 *  - every surface / canvas call is wrapped; repeated failures pause rendering and retry later
 *  - sensors are only registered while visible; receivers are removed in onDestroy
 */
public class AlpenglowService extends WallpaperService {

    private static final String TAG = "Alpenglow";

    @Override
    public Engine onCreateEngine() {
        return new GlowEngine();
    }

    private final class GlowEngine extends Engine implements Choreographer.FrameCallback, SensorEventListener {

        private final Handler main = new Handler(Looper.getMainLooper());
        private HandlerThread thread;
        private Handler rh;                       // render-thread handler
        private Choreographer choreo;
        private SceneRenderer renderer;
        private final Settings settings = new Settings();
        private SharedPreferences prefs;
        private SharedPreferences.OnSharedPreferenceChangeListener prefListener;

        private volatile boolean destroyed;
        private boolean visible;
        private boolean surfaceOk;
        private boolean receiversOn;
        private int errors;
        private long frameIntervalMs = 33L;

        // sensors
        private SensorManager sm;
        private Sensor accel;
        private boolean sensing;
        private float baseX, baseY;
        private boolean baseInit;
        private long lastSensorNs;

        // events
        private long hiddenAtMs;
        private boolean unlockPending;
        private long unlockAtMs;
        private boolean plugged;
        private float battLevel = 0.5f;
        private boolean powerSave;
        private PowerManager pm;

        // system theme colours
        private volatile int[] theme = new int[]{0xFF5A2A8A, 0xFFD2507E, 0xFF161A62};
        private long lastThemeCheck;
        private int[] lastNotified = null;

        // ------------------------------------------------------------ lifecycle (main thread)
        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            prefs = getSharedPreferences(Settings.PREFS, Context.MODE_PRIVATE);
            try {
                settings.load(prefs);
            } catch (Throwable t) {
                Log.w(TAG, "settings load failed", t);
            }
            sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
            accel = sm != null ? sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) : null;
            pm = (PowerManager) getSystemService(Context.POWER_SERVICE);

            thread = new HandlerThread("AlpenglowRender", Process.THREAD_PRIORITY_DISPLAY);
            thread.start();
            rh = new Handler(thread.getLooper());
            renderer = new SceneRenderer();
            renderer.cfg = settings;

            setTouchEventsEnabled(false);
            enableOffsets();

            prefListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
                @Override
                public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
                    post(new Runnable() {
                        @Override
                        public void run() {
                            reloadSettings();
                        }
                    });
                }
            };
            prefs.registerOnSharedPreferenceChangeListener(prefListener);

            post(new Runnable() {
                @Override
                public void run() {
                    choreo = Choreographer.getInstance();
                    registerReceivers();
                    updatePower();
                }
            });
        }

        @Override
        public void onDestroy() {
            destroyed = true;
            try {
                if (prefs != null && prefListener != null) prefs.unregisterOnSharedPreferenceChangeListener(prefListener);
            } catch (Throwable ignored) {
            }
            try {
                if (receiversOn) unregisterReceiver(receiver);
            } catch (Throwable ignored) {
            }
            receiversOn = false;
            try {
                if (sm != null) sm.unregisterListener(this);
            } catch (Throwable ignored) {
            }
            try {
                if (choreo != null) choreo.removeFrameCallback(this);
            } catch (Throwable ignored) {
            }
            if (rh != null) rh.removeCallbacksAndMessages(null);
            if (thread != null) thread.quitSafely();
            main.removeCallbacksAndMessages(null);
            super.onDestroy();
        }

        private void enableOffsets() {
            // setOffsetNotificationsEnabled is resolved reflectively so a missing symbol can never break the build.
            try {
                Engine.class.getMethod("setOffsetNotificationsEnabled", boolean.class).invoke(this, Boolean.TRUE);
            } catch (Throwable ignored) {
            }
        }

        private void post(Runnable r) {
            Handler h = rh;
            if (h != null && !destroyed) {
                try {
                    h.post(r);
                } catch (Throwable ignored) {
                }
            }
        }

        // ------------------------------------------------------------ surface callbacks (main thread -> render thread)
        @Override
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            post(new Runnable() {
                @Override
                public void run() {
                    surfaceOk = true;
                    kick();
                }
            });
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, final int width, final int height) {
            super.onSurfaceChanged(holder, format, width, height);
            post(new Runnable() {
                @Override
                public void run() {
                    try {
                        renderer.setSize(width, height);
                    } catch (Throwable t) {
                        Log.w(TAG, "setSize failed", t);
                    }
                    surfaceOk = true;
                    kick();
                }
            });
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            post(new Runnable() {
                @Override
                public void run() {
                    surfaceOk = false;
                    stopLoop();
                }
            });
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onVisibilityChanged(final boolean isVisible) {
            super.onVisibilityChanged(isVisible);
            post(new Runnable() {
                @Override
                public void run() {
                    setVisible(isVisible);
                }
            });
        }

        @Override
        public void onOffsetsChanged(float xOffset, float yOffset, float xStep, float yStep, int xPixels, int yPixels) {
            super.onOffsetsChanged(xOffset, yOffset, xStep, yStep, xPixels, yPixels);
            final float x = xOffset;
            post(new Runnable() {
                @Override
                public void run() {
                    renderer.setScroll(x);
                }
            });
        }

        @Override
        public Bundle onCommand(String action, final int x, final int y, int z, Bundle extras, boolean resultRequested) {
            if ("android.wallpaper.tap".equals(action) || "android.wallpaper.secondaryTap".equals(action)) {
                post(new Runnable() {
                    @Override
                    public void run() {
                        renderer.tap(x, y);
                    }
                });
            }
            return null;
        }

        @Override
        public WallpaperColors onComputeColors() {
            int[] t = theme;
            try {
                return new WallpaperColors(Color.valueOf(t[0]), Color.valueOf(t[1]), Color.valueOf(t[2]));
            } catch (Throwable e) {
                return null;
            }
        }

        // ------------------------------------------------------------ render-thread logic
        private void reloadSettings() {
            try {
                settings.load(prefs);
            } catch (Throwable t) {
                Log.w(TAG, "settings reload failed", t);
            }
            renderer.invalidatePalette();
            updatePower();
            if (visible) {
                if (settings.parallax) startSensors(); else stopSensors();
            }
            kick();
        }

        private void setVisible(boolean v) {
            if (v == visible) return;
            visible = v;
            long now = SystemClock.uptimeMillis();
            if (v) {
                refreshBatterySticky();
                updatePower();
                if (settings.parallax) startSensors();
                boolean longHidden = hiddenAtMs > 0L && now - hiddenAtMs > 1500L;
                if (unlockPending) {
                    unlockPending = false;
                    if (now - unlockAtMs < 3500L) renderer.triggerUnlock();
                    else if (longHidden) renderer.triggerWake();
                } else if (longHidden) {
                    renderer.triggerWake();
                }
                kick();
            } else {
                hiddenAtMs = now;
                stopSensors();
                stopLoop();
            }
        }

        private void onUnlock() {
            long now = SystemClock.uptimeMillis();
            if (visible) {
                renderer.triggerUnlock();
                unlockPending = false;
            } else {
                unlockPending = true;
                unlockAtMs = now;
            }
        }

        private void applyBattery(Intent i) {
            int plug = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            int lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            float f = (lvl >= 0 && scale > 0) ? lvl / (float) scale : 0.5f;
            plugged = plug != 0;
            battLevel = f;
            renderer.setPlugged(plugged, f);
            updatePower();
            if (visible) kick();
        }

        private void refreshBatterySticky() {
            try {
                Intent sticky = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (sticky != null) applyBattery(sticky);
            } catch (Throwable ignored) {
            }
        }

        private void updatePower() {
            try {
                powerSave = pm != null && pm.isPowerSaveMode();
            } catch (Throwable t) {
                powerSave = false;
            }
            boolean lowBatt = !plugged && battLevel < 0.15f;
            renderer.setLowPower(powerSave || lowBatt);
            int fps = settings.fps;
            if (powerSave) fps = Math.min(fps, 15);
            else if (lowBatt) fps = Math.min(fps, 20);
            frameIntervalMs = Math.max(8L, 1000L / Math.max(5, fps));
        }

        private final BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (destroyed || intent == null) return;
                String a = intent.getAction();
                if (a == null) return;
                if (Intent.ACTION_BATTERY_CHANGED.equals(a)) applyBattery(intent);
                else if (Intent.ACTION_USER_PRESENT.equals(a)) onUnlock();
                else if (PowerManager.ACTION_POWER_SAVE_MODE_CHANGED.equals(a)) updatePower();
            }
        };

        private void registerReceivers() {
            if (receiversOn || destroyed) return;
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_BATTERY_CHANGED);
            f.addAction(Intent.ACTION_USER_PRESENT);
            f.addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED);
            Intent sticky = null;
            try {
                sticky = registerReceiver(receiver, f, null, rh);
                receiversOn = true;
            } catch (Throwable t) {
                if (Build.VERSION.SDK_INT >= 33) {
                    try {
                        sticky = registerReceiver(receiver, f, null, rh, Context.RECEIVER_NOT_EXPORTED);
                        receiversOn = true;
                    } catch (Throwable t2) {
                        Log.w(TAG, "receiver registration failed", t2);
                    }
                } else {
                    Log.w(TAG, "receiver registration failed", t);
                }
            }
            if (sticky != null) applyBattery(sticky);
        }

        // ------------------------------------------------------------ sensors
        private void startSensors() {
            if (sensing || sm == null || accel == null) return;
            baseInit = false;
            lastSensorNs = 0L;
            try {
                sensing = sm.registerListener(this, accel, SensorManager.SENSOR_DELAY_UI, rh);
            } catch (Throwable t) {
                sensing = false;
            }
        }

        private void stopSensors() {
            if (!sensing) return;
            try {
                sm.unregisterListener(this);
            } catch (Throwable ignored) {
            }
            sensing = false;
            renderer.setTilt(0f, 0f);
        }

        @Override
        public void onSensorChanged(SensorEvent e) {
            if (destroyed || e == null || e.values == null || e.values.length < 2) return;
            float gx = e.values[0] / 9.81f;
            float gy = e.values[1] / 9.81f;
            float dt = lastSensorNs == 0L ? 0.06f : (e.timestamp - lastSensorNs) / 1.0e9f;
            lastSensorNs = e.timestamp;
            if (dt < 0.001f) dt = 0.001f;
            if (dt > 0.5f) dt = 0.5f;
            if (!baseInit) {
                baseX = gx;
                baseY = gy;
                baseInit = true;
            }
            // slow re-centering: parallax is relative to how the phone is held
            float k = 1f - (float) Math.exp(-dt / 5f);
            baseX += (gx - baseX) * k;
            baseY += (gy - baseY) * k;
            renderer.setTilt((gx - baseX) / 0.30f, (gy - baseY) / 0.30f);
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }

        // ------------------------------------------------------------ frame loop (render thread)
        private void kick() {
            if (destroyed || !visible || !surfaceOk || choreo == null) return;
            try {
                choreo.removeFrameCallback(this);
                choreo.postFrameCallback(this);
            } catch (Throwable ignored) {
            }
        }

        private void stopLoop() {
            try {
                if (choreo != null) choreo.removeFrameCallback(this);
            } catch (Throwable ignored) {
            }
        }

        @Override
        public void doFrame(long frameTimeNanos) {
            if (destroyed || !visible || !surfaceOk) return;
            long start = SystemClock.uptimeMillis();
            boolean ok = drawFrame(start);
            long spent = SystemClock.uptimeMillis() - start;
            if (!ok && errors >= 6) {
                // something is wrong with the surface; back off instead of spinning
                errors = 0;
                try {
                    choreo.postFrameCallbackDelayed(this, 2000L);
                } catch (Throwable ignored) {
                }
                return;
            }
            long delay = frameIntervalMs - spent - 6L;
            if (delay < 0L) delay = 0L;
            try {
                choreo.postFrameCallbackDelayed(this, delay);
            } catch (Throwable ignored) {
            }
            maybeUpdateTheme(start);
        }

        private boolean drawFrame(long nowMs) {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockHardwareCanvas();
            } catch (Throwable t) {
                canvas = null;
            }
            if (canvas == null) {
                try {
                    canvas = holder.lockCanvas();
                } catch (Throwable t) {
                    canvas = null;
                }
            }
            if (canvas == null) {
                errors++;
                return false;
            }
            boolean ok = true;
            try {
                renderer.draw(canvas, nowMs, System.currentTimeMillis());
                errors = 0;
            } catch (Throwable t) {
                ok = false;
                errors++;
                if (errors == 1) Log.w(TAG, "draw failed", t);
            } finally {
                try {
                    holder.unlockCanvasAndPost(canvas);
                } catch (Throwable ignored) {
                }
            }
            return ok;
        }

        private void maybeUpdateTheme(long now) {
            if (now - lastThemeCheck < 120000L && lastNotified != null) return;
            lastThemeCheck = now;
            int[] t = renderer.themeColors();
            theme = t;
            boolean changed = lastNotified == null;
            if (!changed) {
                for (int i = 0; i < 3; i++) {
                    if (colorDist(t[i], lastNotified[i]) > 60) {
                        changed = true;
                        break;
                    }
                }
            }
            if (changed) {
                lastNotified = t;
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        if (destroyed) return;
                        try {
                            notifyColorsChanged();
                        } catch (Throwable ignored) {
                        }
                    }
                });
            }
        }

        private int colorDist(int a, int b) {
            int dr = Math.abs(((a >> 16) & 255) - ((b >> 16) & 255));
            int dg = Math.abs(((a >> 8) & 255) - ((b >> 8) & 255));
            int db = Math.abs((a & 255) - (b & 255));
            return dr + dg + db;
        }
    }
}
