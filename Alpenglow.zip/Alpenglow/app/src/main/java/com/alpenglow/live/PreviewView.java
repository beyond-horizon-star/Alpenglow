package com.alpenglow.live;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;

/** Live in-app preview. Uses the exact same SceneRenderer as the wallpaper. */
public class PreviewView extends View {

    private final SceneRenderer renderer = new SceneRenderer();
    private boolean running;
    private float corner;

    public PreviewView(Context context) {
        super(context);
        corner = 22f * context.getResources().getDisplayMetrics().density;
        setClipToOutline(true);
        setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), corner);
            }
        });
    }

    void applySettings(Settings s) {
        renderer.cfg = s;
        renderer.invalidatePalette();
    }

    /** hour 0..24, or negative to follow the system clock. */
    void setPreviewHour(float hour) {
        renderer.hourOverride = hour;
        renderer.invalidatePalette();
    }

    void simulateCharging(boolean on, float level) {
        renderer.setPlugged(on, level);
    }

    void simulateUnlock() {
        renderer.triggerUnlock();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        renderer.setSize(w, h);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = true;
        postInvalidateOnAnimation();
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        super.onDetachedFromWindow();
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        if (visibility == VISIBLE && running) postInvalidateOnAnimation();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        try {
            renderer.draw(canvas, SystemClock.uptimeMillis(), System.currentTimeMillis());
        } catch (Throwable ignored) {
        }
        if (running && getVisibility() == VISIBLE) postInvalidateOnAnimation();
    }

    /** Drag on the preview to tilt the scene, tap the lake for ripples. */
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int w = Math.max(1, getWidth()), h = Math.max(1, getHeight());
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                renderer.tap(e.getX(), e.getY());
                renderer.setTilt((e.getX() / w - 0.5f) * 2f, (e.getY() / h - 0.5f) * 2f);
                return true;
            case MotionEvent.ACTION_MOVE:
                renderer.setTilt((e.getX() / w - 0.5f) * 2f, (e.getY() / h - 0.5f) * 2f);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                renderer.setTilt(0f, 0f);
                return true;
            default:
                return super.onTouchEvent(e);
        }
    }
}
