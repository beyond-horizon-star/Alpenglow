package com.alpenglow.live;

import android.app.Activity;
import android.app.WallpaperInfo;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Locale;

/** Preview + settings. Doubles as the wallpaper's settings screen. UI is built in code (no layout XML to break). */
public class MainActivity extends Activity {

    private static final int BG = 0xFF0B0D14;
    private static final int CARD = 0xFF151826;
    private static final int TEXT = 0xFFEDEFF7;
    private static final int MUTED = 0xFF8C93A8;
    private static final int ACCENT = 0xFFFF9A5C;

    private SharedPreferences prefs;
    private final Settings settings = new Settings();
    private PreviewView preview;
    private TextView statusLabel, timeLabel, intensityLabel, sunriseLabel, sunsetLabel;
    private SeekBar timeSeek;
    private Switch followSwitch;
    private Button chargeBtn;
    private boolean chargeSim;
    private boolean building;
    private float density;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = getResources().getDisplayMetrics().density;
        prefs = getSharedPreferences(Settings.PREFS, MODE_PRIVATE);
        settings.load(prefs);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        building = true;
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(34));
        sv.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("Alpenglow", 30, TEXT, true);
        root.addView(title, lp(-2, -2, 0));
        root.addView(text("A living alpine lake. Follows your clock, the moon, your battery and your tilt.", 14, MUTED, false), lp(-1, -2, 4));

        // ---- preview
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int pw = Math.min((int) (screenW * 0.60f), dp(250));
        int ph = (int) (pw * 2.1f);
        preview = new PreviewView(this);
        preview.applySettings(settings);
        LinearLayout.LayoutParams plp = lp(pw, ph, 18);
        plp.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(preview, plp);
        TextView hint = text("Drag on the preview to tilt it. Tap the lake for ripples.", 12, MUTED, false);
        hint.setGravity(Gravity.CENTER);
        root.addView(hint, lp(-1, -2, 8));

        statusLabel = text("", 13, MUTED, false);
        statusLabel.setGravity(Gravity.CENTER);
        root.addView(statusLabel, lp(-1, -2, 10));

        Button set = button("Set as live wallpaper", true);
        set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWallpaperPicker();
            }
        });
        root.addView(set, lp(-1, dp(52), 10));

        // ---- try it
        LinearLayout tryCard = card(root, "Try it");
        followSwitch = new Switch(this);
        followSwitch.setText("Follow system clock");
        followSwitch.setTextColor(TEXT);
        followSwitch.setChecked(true);
        tryCard.addView(followSwitch, lp(-1, -2, 4));
        timeLabel = text("", 13, MUTED, false);
        tryCard.addView(timeLabel, lp(-1, -2, 8));
        timeSeek = new SeekBar(this);
        timeSeek.setMax(1439);
        timeSeek.setProgress(nowMinutes());
        tryCard.addView(timeSeek, lp(-1, -2, 2));
        timeLabel.setText(clock(nowMinutes()) + "  (live)");
        timeSeek.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (!fromUser) return;
                if (followSwitch.isChecked()) followSwitch.setChecked(false);
                timeLabel.setText(clock(p) + "  (preview)");
                preview.setPreviewHour(p / 60f);
            }
        });
        followSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                if (on) {
                    preview.setPreviewHour(-1f);
                    timeSeek.setProgress(nowMinutes());
                    timeLabel.setText(clock(nowMinutes()) + "  (live)");
                } else {
                    preview.setPreviewHour(timeSeek.getProgress() / 60f);
                    timeLabel.setText(clock(timeSeek.getProgress()) + "  (preview)");
                }
            }
        });
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        chargeBtn = button("Simulate charging", false);
        chargeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chargeSim = !chargeSim;
                preview.simulateCharging(chargeSim, 0.62f);
                chargeBtn.setText(chargeSim ? "Stop charging" : "Simulate charging");
            }
        });
        Button unlockBtn = button("Simulate unlock", false);
        unlockBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preview.simulateUnlock();
            }
        });
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(46), 1f);
        half.rightMargin = dp(6);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(46), 1f);
        half2.leftMargin = dp(6);
        btnRow.addView(chargeBtn, half);
        btnRow.addView(unlockBtn, half2);
        tryCard.addView(btnRow, lp(-1, -2, 12));

        // ---- look
        LinearLayout look = card(root, "Look");
        addSpinner(look, "AMOLED black mode", new String[]{"Off", "Night only (recommended)", "Always black"}, settings.amoled,
                new Picker() {
                    @Override
                    public void picked(int i) {
                        putInt(Settings.K_AMOLED, i);
                    }
                });
        addSwitch(look, "Clouds", settings.clouds, Settings.K_CLOUDS);
        addSwitch(look, "Birds, fireflies & shooting stars", settings.life, Settings.K_LIFE);

        // ---- depth
        LinearLayout depth = card(root, "Depth");
        addSwitch(depth, "Parallax (tilt + home-screen scroll)", settings.parallax, Settings.K_PARALLAX);
        intensityLabel = text("Intensity " + settings.parallaxPct + "%", 13, MUTED, false);
        depth.addView(intensityLabel, lp(-1, -2, 8));
        SeekBar inten = new SeekBar(this);
        inten.setMax(180);
        inten.setProgress(settings.parallaxPct - 20);
        inten.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                intensityLabel.setText("Intensity " + (p + 20) + "%");
                if (fromUser) putInt(Settings.K_PARALLAX_PCT, p + 20);
            }
        });
        depth.addView(inten, lp(-1, -2, 2));

        // ---- events
        LinearLayout ev = card(root, "Events");
        addSwitch(ev, "Charging animation (aurora, energy ripples)", settings.charging, Settings.K_CHARGING);
        addSwitch(ev, "Unlock animation", settings.unlock, Settings.K_UNLOCK);

        // ---- day & night
        LinearLayout dn = card(root, "Day & night");
        sunriseLabel = text("Sunrise " + clock(settings.sunriseMin), 13, MUTED, false);
        dn.addView(sunriseLabel, lp(-1, -2, 4));
        SeekBar sr = new SeekBar(this);
        sr.setMax(420);
        sr.setProgress(settings.sunriseMin - 180);
        sr.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                sunriseLabel.setText("Sunrise " + clock(p + 180));
                if (fromUser) putInt(Settings.K_SUNRISE, p + 180);
            }
        });
        dn.addView(sr, lp(-1, -2, 2));
        sunsetLabel = text("Sunset " + clock(settings.sunsetMin), 13, MUTED, false);
        dn.addView(sunsetLabel, lp(-1, -2, 10));
        SeekBar ss = new SeekBar(this);
        ss.setMax(420);
        ss.setProgress(settings.sunsetMin - 960);
        ss.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                sunsetLabel.setText("Sunset " + clock(p + 960));
                if (fromUser) putInt(Settings.K_SUNSET, p + 960);
            }
        });
        dn.addView(ss, lp(-1, -2, 2));
        dn.addView(text("The moon shows today's real phase.", 12, MUTED, false), lp(-1, -2, 8));

        // ---- performance
        LinearLayout perf = card(root, "Performance");
        int fpsIdx = settings.fps <= 15 ? 0 : (settings.fps >= 60 ? 2 : 1);
        addSpinner(perf, "Frame rate", new String[]{"15 fps (battery saver)", "30 fps (recommended)", "60 fps (smoothest)"}, fpsIdx,
                new Picker() {
                    @Override
                    public void picked(int i) {
                        putInt(Settings.K_FPS, i == 0 ? 15 : (i == 2 ? 60 : 30));
                    }
                });
        perf.addView(text("Drawing stops completely whenever the screen is off or an app covers the wallpaper. "
                + "Battery Saver and low battery automatically lower the frame rate and darken the scene.", 12, MUTED, false), lp(-1, -2, 8));

        // ---- about always-on
        LinearLayout aod = card(root, "About Always-On Display");
        aod.addView(text("Android does not let any wallpaper draw on the system's Always-On Display - the phone itself controls that screen. "
                + "AMOLED black mode gives you the next best thing: true black pixels everywhere except the moon, stars and rim-lit peaks, "
                + "so the screen costs almost nothing to light.", 13, MUTED, false), lp(-1, -2, 4));

        setContentView(sv);
        building = false;
        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    // ------------------------------------------------------------------ actions
    private void openWallpaperPicker() {
        try {
            Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, new ComponentName(this, AlpenglowService.class));
            startActivity(i);
        } catch (Throwable t) {
            try {
                startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
            } catch (Throwable t2) {
                Toast.makeText(this, "Open Settings > Wallpaper > Live wallpapers and choose Alpenglow.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void updateStatus() {
        boolean active = false;
        try {
            WallpaperInfo info = WallpaperManager.getInstance(this).getWallpaperInfo();
            active = info != null && getPackageName().equals(info.getPackageName())
                    && AlpenglowService.class.getName().equals(info.getServiceName());
        } catch (Throwable ignored) {
        }
        statusLabel.setText(active ? "Alpenglow is your live wallpaper" : "Not applied yet");
        statusLabel.setTextColor(active ? 0xFF5BE3B0 : MUTED);
    }

    private void putInt(String key, int v) {
        if (building) return;
        prefs.edit().putInt(key, v).apply();
        settings.load(prefs);
        preview.applySettings(settings);
    }

    private void putBool(String key, boolean v) {
        if (building) return;
        prefs.edit().putBoolean(key, v).apply();
        settings.load(prefs);
        preview.applySettings(settings);
    }

    // ------------------------------------------------------------------ tiny UI kit
    private interface Picker {
        void picked(int index);
    }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
        }
    }

    private int dp(int v) {
        return (int) (v * density + 0.5f);
    }

    private int nowMinutes() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
    }

    private static String clock(int minutes) {
        int m = ((minutes % 1440) + 1440) % 1440;
        return String.format(Locale.US, "%02d:%02d", m / 60, m % 60);
    }

    private LinearLayout.LayoutParams lp(int w, int h, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(topDp);
        return p;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(primary ? 0xFF1B1020 : TEXT);
        b.setTextSize(15);
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(dp(14));
        d.setColor(primary ? ACCENT : 0xFF232840);
        b.setBackground(d);
        return b;
    }

    private LinearLayout card(LinearLayout parent, String heading) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        GradientDrawable d = new GradientDrawable();
        d.setColor(CARD);
        d.setCornerRadius(dp(18));
        c.setBackground(d);
        c.addView(text(heading, 16, ACCENT, true), lp(-1, -2, 0));
        parent.addView(c, lp(-1, -2, 16));
        return c;
    }

    private void addSwitch(LinearLayout parent, String label, boolean initial, final String key) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(TEXT);
        s.setChecked(initial);
        s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                putBool(key, on);
            }
        });
        parent.addView(s, lp(-1, -2, 12));
    }

    private void addSpinner(LinearLayout parent, String label, String[] items, int selected, final Picker picker) {
        parent.addView(text(label, 13, MUTED, false), lp(-1, -2, 10));
        Spinner sp = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(ad);
        sp.setSelection(Math.max(0, Math.min(items.length - 1, selected)), false);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View view, int position, long id) {
                picker.picked(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }
        });
        parent.addView(sp, lp(-1, -2, 2));
    }
}
