# Alpenglow - live wallpaper

Procedural alpine-lake live wallpaper. Pure Java, zero third-party dependencies.

- Real day/night cycle from the system clock (adjustable sunrise / sunset) and the real moon phase for today's date
- Four parallax mountain layers, lake reflection, snow caps that catch the alpenglow, clouds, birds, fireflies, shooting stars
- Depth effect: accelerometer tilt plus home-screen scroll parallax
- AMOLED black mode (off / night only / always)
- Charging animation: energy ripple on plug-in, aurora at night, rising motes, horizon battery line
- Unlock animation: camera push, light flare, horizon gleam
- Draws only while visible, one render thread, Battery Saver aware

## Build the APK from a phone (free)

1. Create a free account at github.com, then a **new public repository** (any name).
2. Repository page -> **Add file -> Upload files** -> choose `Alpenglow.zip` (do not unzip it) -> Commit changes.
3. **Add file -> Create new file**, name it `.github/workflows/build.yml`, paste the zip-based workflow from the chat message -> Commit changes.
4. Open the **Actions** tab and wait about 4 minutes for the green check.
5. Repository page -> **Releases -> latest** -> download `Alpenglow.apk` and install it (allow "install unknown apps" for your browser or file manager).
6. Open Alpenglow -> **Set as live wallpaper**.

If the build fails, open the failed run, copy the red error lines and send them back.
